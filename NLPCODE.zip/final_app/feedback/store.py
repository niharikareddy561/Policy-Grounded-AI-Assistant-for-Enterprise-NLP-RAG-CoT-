# feedback/store.py
import json
from pathlib import Path
from datetime import datetime

def save_feedback(payload: dict):
    fb_dir = Path(__file__).parent.parent / "feedback"  # project_root/feedback/
    fb_dir.mkdir(exist_ok=True)
    data = dict(payload)
    data["ts"] = datetime.utcnow().isoformat() + "Z"
    with open(fb_dir / "feedback.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(data, ensure_ascii=False) + "\n")
