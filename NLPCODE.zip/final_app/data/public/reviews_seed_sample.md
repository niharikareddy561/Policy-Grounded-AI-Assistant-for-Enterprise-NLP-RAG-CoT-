

label: Billing/Refunds
stars: 1

I was billed twice for the same headset. Please reverse the duplicate charge today.



label: Delivery/Logistics
stars: 1

Package says delivered with a photo, but that lobby isn’t mine. Nothing at my door.




label: Support Responsiveness
stars: 2

I opened a ticket last week and haven’t had a single reply. The chat just closes.


label: Security/Fraud
stars: 2

Got a password reset email I didn’t request and a login from another country.


label: Praise
stars: 5

Brilliant service—placed an order at night and it arrived before lunch next day.


label: Delivery/Logistics
stars: 2

Courier left the parcel under the letterboxes in the rain. The box is soaked.


label: Billing/Refunds
stars: 1

Refund still not processed after ten days, despite sending proof of the return.


label: Support Responsiveness
stars: 1

Three emails, no response. I just need a straight answer about my warranty.


label: Security/Fraud
stars: 1

Why are you keeping my personal data after I close my account? Please delete it.


label: Praise
stars: 5

Customer service fixed a sizing mistake immediately and arranged free pickup.

# Amazon AU/NZ Public Reviews (2025 sample)
_Source: user-provided sample text. Use for testing classification and retrieval._

---

## Review 1 — Refund refusal & packaging
Shame there is no 0 star option. Basically it is a scammer refuses to process a refund after returning items arrived broken simply because it a cheapskate by shipping item in a paper satchel with zero protection.

- Theme: refunds refused, damaged items, poor packaging
- Suggested route: Billing/Refunds (primary), Fulfilment QA (secondary)

---

## Review 2 — Prime linking & support frustration
Amazon Australia is useless, Shipping takes as long as temu may swell be shopping with them. Amazon's customer service is non existent, get more sense from a brick wall. Prime account doesn't link and amazon refuse to link the accounts. SO NO SAVINGS TO BE HAD FROM PRIME. I'm cancelling my membership

- Theme: account linking, support responsiveness
- Suggested route: Account Support / Prime

---

## Review 3 — Refund delayed (Pretty Little Things)
I am so disappointed with the customer service given to me. It's been 10 days and I have tried and tried to get a refund from the company Pretty Little Things. To no avail.

- Theme: refund delay
- Suggested route: Billing/Refunds; Support follow-up

---

## Review 4 — Misdelivery / exposed parcels / missing orders
This happens to me: - Orders left as shown in photo, or under the letterboxes. One delivery was marked, "delivered to mail room." The area is exposed to the weather and passing foot traffic. Orders left in the lobby of the wrong block of apartments. I've had two orders go completely missing.

- Theme: last-mile delivery errors, losses
- Suggested route: Delivery Ops; Request photo-on-delivery

---

## Review 5 — Driver can’t find accessible door
Once again Amazon delivery driver thought my front door was behind a 2 metre high fence. Front door is accessible from the road with ease.

- Theme: address notes / courier training
- Suggested route: Delivery Ops

---

## Review 6 — Late delivery & price dissatisfaction
I purchased Prebiotic powder cost $32.93 not yet delivered after one week delivered. Discovered price in local pharmacy $19.50. RIDICULOUS

- Theme: delay + pricing complaint
- Suggested route: Delivery SLA; Merch/Pricing review

---

## Review 7 — Praise: quality & next-day delivery
I can not express how much Amazon has helped with quality products, next day delivery and affordable prices. Amazon is life

- Theme: positive experience
- Suggested route: CSAT/NPS logging

---

## Review 8 — Praise: smooth refund & pickup
I recently had a great dealing with Amazon NZ Australia. I unfortunately chose the wrong size… Amazon made things so easy… picked up next day and refunded immediately.

- Theme: positive refunds process
- Suggested route: CSAT/NPS exemplars

---

## Review 9 — Praise: very fast delivery (books/garden)
Fast delivery – I have had three deliveries from Amazon Australia in the last month… books ordered late at night arrived by midday next day, brilliant service

- Theme: fast delivery
- Suggested route: CSAT/NPS logging

---

## Review 10 — Praise: packing quality & fast delivery
Super impressive – Good are always packed nicely… Delivery is super fast… customer service number one.

- Theme: well-packed, fast, good CS
- Suggested route: CSAT/NPS logging

---

## Review 11 — Faulty item & international return postage
Amazon let down – faulty bike light; expected to pay postage back to USA; support vague and short, refer to international sales; going back to eBay.

- Theme: return policy / cross-border returns cost
- Suggested route: Billing/Refunds; Returns policy clarification

---

## Review 12 — Item missing from delivered box
Item was not delivered… driver took a photo BUT the $90 [item] was not included. Wouldn’t have fit in the box with other stuff.

- Theme: partial delivery / missing item
- Suggested route: Delivery Ops; Refunds/Replacement

---

## Review 13 — Gift card not working; chat kept disconnecting
The worst experience – gift card didn’t work; chat disconnected repeatedly; repeated explanations; no resolution; supervisor left chat.

- Theme: support responsiveness, gift card issue
- Suggested route: Payments/Gift Cards Support; Escalation
