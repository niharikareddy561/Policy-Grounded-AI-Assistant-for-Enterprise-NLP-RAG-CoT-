# Authentication & Account Access


## Rules
- Password minimum: 10 chars; support for passkeys.  
- 2FA optional; enforced on staff accounts.  
- Account lock after 5 failed attempts; unlock via email link.

## SOP
1. Verify identity (email + order ID or phone OTP).
2. Reset or unlock account; log event in security ledger.
3. If suspicious activity → force password reset and 2FA prompt.
