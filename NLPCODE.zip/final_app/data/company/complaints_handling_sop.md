# Complaints Handling SOP



## SOP
1. Acknowledge within 24 hrs; provide case ID.  
2. Classify: Billing/Refunds, Delivery/Logistics, Support Responsiveness, Security/Fraud, Praise.  
3. Apply the corresponding policy; state timelines and fees.  
4. If unresolved after 5 business days, escalate to Complaints Manager.  
5. Log resolution and share survey link.
