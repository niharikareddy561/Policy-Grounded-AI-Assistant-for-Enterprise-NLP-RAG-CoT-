# Delivery & Logistics



## Rules
- Standard delivery: 2–6 business daysmetro; 3–10regional.  
- Signatures required for items >$200, otherwise ATL (Authority to Leave) optional.  
- Courier photo proof required for ATL deliveries.

## SOP
1. Verify address and delivery option (signature/ATL).
2. For lost-in-transit: file carrier trace within 24h; update customer every 8h.
3. Confirm outcome (found/refund/replace). Replace or refund within 3 business days.
