# Moderation & Abuse



## Rules
- Zero tolerance for hate speech, threats, or doxxing in reviews or support chats.
- Spam filters auto-hide messages with high risk score.

## SOP
1. Flag content; review within 24h.
2. If violation, remove and warn; repeat offenders → account suspension.
