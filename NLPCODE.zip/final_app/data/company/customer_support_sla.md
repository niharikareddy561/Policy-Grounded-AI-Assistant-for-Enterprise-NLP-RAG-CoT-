# Customer Support SLA



## Targets
- First response: <24h weekdays, <48hweekends.
- Resolution target: 5 business days for standard cases; 24h for payment errors.

## SOP
1. Auto-acknowledge ticket and classify priority.  
2. If no agent reply within SLA-1h buffer → auto-escalate to Team Lead.  
3. Share final resolution and link relevant policy.
