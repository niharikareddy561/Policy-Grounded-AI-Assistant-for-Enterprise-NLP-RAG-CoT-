# Reporting Security Issues — Amazon AU (Paraphrased SOP)

Purpose  
Give agents and automation a consistent flow for handling *security problems*, including suspicious account activity and vulnerability reports.

Scope  
Covers Amazon.com.au retail customers and retail services. AWS security reports follow the AWS flow (separate). Copyright, recruiting fraud, and general scams have their own routes (see below).

---

## A) Customer account / activity concerns (support route)
Use Customer Service for:
- Unknown/suspicious orders or charges
- Unexpected password or account setting changes
- Potential account takeover or fraud flags

Agent steps
1. Authenticate the customer (standard verification).  
2. Contain: force sign-out on all devices; recommend password reset + enable MFA/passkey.  
3. Review recent orders, devices, addresses, and payments; cancel/lock where appropriate.  
4. Escalate to the fraud/security queue if patterns indicate compromise.  
5. Educate: link to “Protect Your System” and “Identify if a message is from Amazon”.

---

## B) Vulnerability reports (researcher route)
For suspected security vulnerabilities in Amazon retail sites/apps/devices:
- Direct to the web form (Amazon Vulnerability Research Program / HackerOne).
- Only vulnerability submissions are handled via this channel; other issues use Customer Service.

Agent steps
1. Thank the reporter; confirm this is a *vulnerability*, not an account issue.  
2. Provide the official submission link and ask for details (affected service, steps, impact, PoC).  
3. Do not request credentials or personal data; keep communications minimal and secure.  
4. Do not promise bounties or timelines—refer to program terms.

> Not a vulnerability? Route to the correct queue (Section A/C/D/E).

---

## C) AWS (cloud) vulnerability reports
- Direct to AWS Vulnerability Reporting (separate program/site).  
- Do not file AWS issues through retail channels.

---

## D) Copyright/IP complaints
- Route to Report Infringement flow (dedicated form).  
- Do not assess legal merits in support; collect required fields and submit.

---

## E) Recruiting fraud & scams
- Recruiting fraud (fake job offers): send to Report a Scam (recruiting).  
- Suspicious emails/SMS/calls/webpages impersonating Amazon: Report a Scam and share guidance on how to recognize official communications.

---

## F) Quick customer guidance (template)
> “Thanks for contacting us. I’ll help secure your account first by signing out other sessions and assisting with a password reset and MFA. If you believe you’ve found a security vulnerability in an Amazon retail site/app/device, please submit it via our official vulnerability form so our security team can review it. For AWS cloud issues, use the AWS security report page. For copyright or scam reports, I can direct you to the right form.”

---

## G) Related references (for agents)
- Unknown charges / Account on hold / Protect Your System  
- Identify real Amazon communications (email/phone/SMS/web)  
- Manage your personal information 
- Trustworthy Shopping at Amazon

---

## Notes
- Do not request sensitive credentials or full card numbers.  
- Never share internal tooling or investigation details with reporters.  
- Keep interaction logs minimal and factual; include timestamps and links.  
- Escalate immediately if there is evidence of active compromise affecting multiple users.

---

## Source
- Amazon AU Help — *Report a Security Issue* (accessed: 24 Sep 2025).
