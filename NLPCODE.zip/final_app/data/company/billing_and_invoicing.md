# Billing & Invoicing



## Rules
- Payment methods: Visa/Mastercard/Amex/PayPal.  
- Invoices are emailed at purchase time; PDF copies available in the account portal.  
- Duplicate charges are automatically detected; suspected duplicates are refunded within 3 business days.

## SOP
1. Validate transaction ID and card tail digits with the customer.
2. If duplicate → create refund case; mark as priority.
3. Post refund in gateway; send confirmation email with reference.
