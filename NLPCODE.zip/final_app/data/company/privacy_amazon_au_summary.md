# Privacy (Amazon AU) — Internal SOP (Paraphrased)

Purpose 
Give support/compliance teams a quick, consistent way to answer privacy questions about what data is collected, why, how it’s shared, and customer choices.

Scope 
Covers Amazon.com.au services and Amazon devices/apps that reference the AU Privacy Notice. Some features or third-party offerings (e.g., seller services, apps, skills) have extra terms—check those if relevant.

---

## A. What data is collected
- Provided by customer: account/profile info, addresses, payment details, messages to support, reviews/ratings, survey responses.
- Automatic: device/browser info, IP, cookies/IDs, clickstream, content interaction (streams/downloads), app and device metrics, location (when enabled).
- From others: updated delivery/address info from carriers, co-branded partners, credit risk data (fraud prevention), interactions with affiliates/linked services.

## B. Why it’s used (main purposes)
-   Fulfilment & service  : take orders, deliver, process payments, communicate about orders/services.
-   Operate & improve  : troubleshoot, measure performance, enhance usability and security.
-   Personalisation  : recommendations, preferences, tailored experience.
-   Voice/image/camera features  : respond to requests and improve those services.
-   Legal & compliance  : identity checks for sellers, regulatory obligations.
-   Communications  : service messages via phone/email/chat.
-   Advertising  : show interest-based ads (without directly identifying info).
-   Fraud/credit risk  : detect/prevent abuse and manage credit risk.

## C. Cookies & identifiers
- Cookies and other identifiers help recognize browsers/devices, enable core features (cart, checkout, sign-in), and improve experience. Users can manage cookie settings; disabling may break essential functions.

## D. Sharing personal information (typical cases)
-   Transactions with third parties  : info shared as needed when you buy from a seller or use third-party apps/skills.
-   Service providers  : delivery, payments, analytics, customer service—access limited to what’s needed.
-   Business transfers  : during mergers/acquisitions, honoring prior privacy commitments.
-   Protection/legal  : to comply with law, enforce terms, or protect safety/rights.
-   Notice & choices  : where not covered above, customers are notified and may opt out.

## E. Security practices
- Encryption in transit; PCI DSS for card data.
- Physical/electronic/procedural safeguards; identity checks before disclosure.
- Device security controls available to customers.
- Customers should protect passwords and sign out on shared devices.

## F. Choices & controls
- Manage communications via   Customer Communication Preferences  .
- Adjust   Advertising Preferences   to limit interest-based ads.
- Browser/app/device controls for cookies, notifications, and permissions.
- Access/update many data fields in   Your Account  ; some services have dedicated settings (e.g.,   Manage Your Content and Devices  ).
- Requests for access/correction handled as required by law.

## G. Children
- Purchases by adults; under-18s use services only with a parent/guardian. Children’s services have additional notices.

## H. Access & self-service menu (examples to reference)
- Your Account: names, addresses, payment methods, order history.
- Content & Devices: device settings, content, some privacy controls.
- Sellers/developers: Seller Central / Developer portals for their data and preferences.

## I. Customer-facing quick reply template
> “We collect information you provide (like account and order details), technical data from your device and use of our services, and information from partners (like carriers). We use it to deliver orders, improve the service, personalize recommendations, prevent fraud, and meet legal requirements. You can manage communications and ads in your preferences, control cookies in your browser, and access/update many details in Your Account. For specific requests about your data, I can point you to the right page or help raise a privacy request.”

---

## Notes for agents
- If the question is about   ads  , point to Advertising Preferences and Interest-Based Ads info.
- If the issue is   data access/correction  , guide to Account pages or the privacy request flow.
- If it involves   children or sensitive data  , escalate to the privacy specialist queue.
- Remind customers that turning off cookies/identifiers can limit shopping features.

---

## Source
- Amazon.com.au   Privacy Notice   (last updated: 2 Oct 2024; accessed: 24 Sep 2025).
