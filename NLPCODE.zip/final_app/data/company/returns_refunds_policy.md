# Returns & Refunds Policy



## Purpose
Define fair, transparent rules for returns and refunds while meeting Australian Consumer Law (ACL) obligations.

## Policy / Rules
- Change of mind: Accepted within 30 days if item is unused and in original packaging; original shipping is non-refundable.
- Large/oversize items: A $50 return shipping fee applies for change-of-mind returns.
- Faulty or damaged on arrival: We provide prepaid return shipping and a full refund or replacement.
- Refund timing: Process refunds within 5 business days of inspection.
- Evidence (photos/serial numbers) may be requested for DOA/defect claims.

## Process (SOP)
1. Verify order ID, purchase date, item condition, and category.
2. Determine eligibility (change of mind vs. ACL fault).
3. Issue prepaid label if eligible; otherwise advise self-ship and expected fees.
4. On receipt, inspect and update disposition (resell / refurbish / scrap).
5. Trigger refund in billing system; notify customer.

## Escalation
- Disputed claims or repeated abuse → escalate to Compliance Lead within 1 business day.
