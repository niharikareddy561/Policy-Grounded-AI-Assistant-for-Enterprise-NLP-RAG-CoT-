# ui/app.py
import json
import requests
import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


st.set_page_config(page_title="Enterprise Compliance Assistant", layout="wide")

#  Sidebar 
st.sidebar.header("Settings")
backend = st.sidebar.text_input("Backend URL", value="http://localhost:8000")
mode = st.sidebar.selectbox("Answer mode", ["baseline", "rag", "cot"], index=1)
clf_method = st.sidebar.selectbox("Classifier", ["traditional", "llm"], index=0)

prov = st.sidebar.selectbox("LLM provider", ["hf", "openai", "local"], index=0)
if prov == "hf":
    mdl = st.sidebar.selectbox("Model", ["google/flan-t5-small", "google/flan-t5-base"], index=0)
elif prov == "openai":
    mdl = st.sidebar.selectbox("Model", ["gpt-4o-mini"], index=0)
else:
    mdl = st.sidebar.selectbox("Model", ["qwen2.5:0.5b", "llama3.2:3b"], index=0)

timeout_ans = st.sidebar.slider("Answer timeout (sec)", 10, 180, 60)
timeout_clf = st.sidebar.slider("Classify timeout (sec)", 5, 90, 30)

col_sb1, col_sb2 = st.sidebar.columns(2)
with col_sb1:
    if st.button("Ping backend", use_container_width=True):
        try:
            r = requests.get(f"{backend}/health", timeout=10)
            r.raise_for_status()
            st.success("OK")
        except Exception as e:
            st.error(f"Health error: {e}")
with col_sb2:
    if st.button("Show raw settings", use_container_width=True):
        st.code(json.dumps({"backend": backend, "mode": mode,
                            "clf_method": clf_method, "provider": prov, "model": mdl}, indent=2))

#  Main 
st.title("Enterprise Compliance Assistant")
q = st.text_area("Paste a review/complaint or ask a question", height=160)

col1, col2, col3 = st.columns(3)

def post_json(url: str, payload: dict, timeout: int):
    r = requests.post(url, json=payload, timeout=timeout)
    r.raise_for_status()
    return r.json()

def render_sources(retrieved: list):
    if not retrieved:
        return
    st.subheader("Sources")
    for rsrc in retrieved:
        rid = rsrc.get("id", "(no id)")
        score = rsrc.get("score", 0.0)
        st.markdown(f"**{rid}** · score={score:.3f}")
        with st.expander("Show snippet"):
            st.write(rsrc.get("text", "(no text)"))

# Classify button 
if col1.button("Classify", use_container_width=True):
    if not q.strip():
        st.warning("Please enter some text first.")
    else:
        try:
            payload = {"text": q, "method": clf_method, "provider": prov, "model": mdl}
            data = post_json(f"{backend}/classify", payload, timeout_clf)
            st.subheader("Classification")
            label = data.get("label", "(unknown)")
            conf = data.get("confidence")
            reason = data.get("reason", "")
            line = f"**Label:** {label}"
            if conf is not None:
                line += f" · **Confidence:** {conf:.2f}"
            st.markdown(line)
            if reason:
                st.caption(f"Reason: {reason}")
            with st.expander("Show raw response"):
                st.code(json.dumps(data, indent=2))
        except Exception as e:
            st.error(f"Classify error: {e}")

# Generate Answer button 
if col2.button("Generate Answer", use_container_width=True):
    if not q.strip():
        st.warning("Please enter a question or complaint first.")
    else:
        try:
            payload = {"question": q, "mode": mode, "provider": prov, "model": mdl}
            data = post_json(f"{backend}/answer", payload, timeout_ans)
            st.subheader("Answer")
            st.write(data.get("answer", "(no answer)"))
            cits = data.get("citations", [])
            if cits:
                st.caption("Citations: " + ", ".join(cits))
            render_sources(data.get("retrieved", []))
            with st.expander("Show raw response"):
                st.code(json.dumps(data, indent=2))
        except Exception as e:
            st.error(f"Answer error: {e}")

# Feedback column 
with col3:
    st.write("Feedback")
    useful_display = st.selectbox("Useful?", ["(select)", "Yes", "No"], index=0)
    useful = None if useful_display == "(select)" else (useful_display == "Yes")
    comment = st.text_input("Comment (optional)", "")
    if st.button("Submit Feedback", use_container_width=True):
        try:
            payload = {"question": q, "answer": "(see above)", "useful": useful, "comment": comment, "sources": []}
            r = requests.post(f"{backend}/feedback", json=payload, timeout=20)
            r.raise_for_status()
            st.success("Thanks! Your feedback was recorded.")
        except Exception as e:
            st.error(f"Feedback error: {e}")

st.markdown("---")
st.markdown("---")
st.header("Classifier Metrics")

metrics_col1, metrics_col2 = st.columns([1,1])
with metrics_col1:
    if st.button("Compute Confusion Matrix & Metrics"):
        try:
            r = requests.get(f"{backend}/metrics", params={"method":"traditional"}, timeout=60)
            r.raise_for_status()
            met = r.json()
            labels = met["labels"]
            cm = np.array(met["confusion_matrix"])

            # Confusion matrix as a heatmap
            fig, ax = plt.subplots(figsize=(6, 5))
            im = ax.imshow(cm, aspect="auto")  # default colormap
            ax.set_xticks(range(len(labels))); ax.set_xticklabels(labels, rotation=45, ha="right")
            ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels)
            ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title("Confusion Matrix")
            # annotate cells
            for i in range(cm.shape[0]):
                for j in range(cm.shape[1]):
                    ax.text(j, i, int(cm[i, j]), ha="center", va="center")
            st.pyplot(fig)

            # Per-class metrics table
            report = met["report"]
            per_class = {k: v for k, v in report.items() if k in labels}
            df = pd.DataFrame(per_class).T[["precision","recall","f1-score","support"]]
            st.subheader("Per-class Precision / Recall / F1")
            st.dataframe(df.style.format({"precision":"{:.2f}", "recall":"{:.2f}", "f1-score":"{:.2f}"}))

            # Macro/weighted summary
            st.subheader("Summary")
            macro = report.get("macro avg", {})
            weighted = report.get("weighted avg", {})
            st.write(f"**Macro F1:** {macro.get('f1-score',0):.2f}  |  **Weighted F1:** {weighted.get('f1-score',0):.2f}")
        except Exception as e:
            st.error(f"Metrics error: {e}")


