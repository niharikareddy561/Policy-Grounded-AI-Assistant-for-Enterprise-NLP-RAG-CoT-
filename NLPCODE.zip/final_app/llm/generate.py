# llm/generate.py
import os, requests, re, string
from pathlib import Path
from rag.retriever import retrieve

# ---------- Prompt loader ----------
def _load_prompt(name: str) -> str:
    return Path(f"prompts/{name}.txt").read_text(encoding="utf-8")

# ---------- Cached HF pipelines by model ----------
_HF_TEXT2TEXT = {}

def _hf_call_text2text(prompt: str, model_name: str) -> str:
    from transformers import pipeline
    if model_name not in _HF_TEXT2TEXT:
        pipe = pipeline("text2text-generation", model=model_name)
        _HF_TEXT2TEXT[model_name] = pipe
    pipe = _HF_TEXT2TEXT[model_name]
    out = pipe(prompt, max_new_tokens=512, do_sample=False, temperature=0.0)[0]["generated_text"]
    return out

# ---------- Provider routers ----------
def _call_openai(prompt: str, model_name: str) -> str:
    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {os.getenv('OPENAI_API_KEY')}",
               "Content-Type": "application/json"}
    body = {
        "model": model_name or os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0, "top_p": 1
    }
    r = requests.post(url, headers=headers, json=body, timeout=60)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]

def _call_ollama(prompt: str, model_name: str) -> str:
    model = model_name or os.getenv("OLLAMA_MODEL", "qwen2.5:0.5b")
    body = {"model": model, "prompt": prompt, "stream": False,
            "options": {"temperature": 0, "top_p": 1}}
    r = requests.post("http://localhost:11434/api/generate", json=body, timeout=90)
    r.raise_for_status()
    return r.json()["response"]

def _call_hf(prompt: str, model_name: str) -> str:
    name = model_name or os.getenv("HF_LLM_MODEL", "google/flan-t5-small")
    return _hf_call_text2text(prompt, name)

def _call_provider(prompt: str, provider: str = None, model: str = None) -> str:
    prov = provider or os.getenv("LLM_PROVIDER", "hf")
    if prov == "openai":
        return _call_openai(prompt, model)
    if prov == "local":
        return _call_ollama(prompt, model)
    return _call_hf(prompt, model)  # default hf

# ---------- Snippet hygiene ----------
def _strip_md_tables(text: str) -> str:
    out = []
    for ln in text.splitlines():
        if re.match(r'^\s*\|.*\|\s*$', ln):  # table row
            continue
        if re.match(r'^\s*:?-{3,}\s*(\|\s*:?-{3,}\s*)+$', ln):  # separator
            continue
        out.append(ln)
    return "\n".join(out)

# drop headings, review metadata, and boilerplate (Owner/Version/Effective/Scope/Purpose)
_BOILER_KEYS = ("owner:", "version:", "effective:", "scope:", "purpose:")
def _is_boilerplate_line(s: str) -> bool:
    ls = s.lower().strip()
    # bold markdown variants (**Scope:** etc.)
    if re.match(r'^\s*(\*\*)?(owner|version|effective|scope|purpose)(\*\*)?\s*:', ls):
        return True
    return ls.startswith(_BOILER_KEYS)

def _sanitize_snippets(text: str) -> str:
    text = re.sub(r'<!--.*?-->', ' ', text, flags=re.S)  # remove HTML comments
    cleaned = []
    for ln in text.splitlines():
        s = ln.strip()
        if not s:
            continue
        if s.startswith(("#", "##", "###")):
            continue
        sl = s.lower()
        if sl.startswith(("**label:**", "label:", "stars:")):
            continue
        if re.match(r'^\s*rev-\d+', s, flags=re.I):
            continue
        if _is_boilerplate_line(s):
            continue
        # flatten bullets & kill long separators
        s = re.sub(r'^\s*[-*]\s+', '', s)
        s = re.sub(r'\s*---+\s*', ' ', s)
        if s:
            cleaned.append(s)
    return "\n".join(cleaned)

def _trim_snippets(text: str, max_chars: int = 6000) -> str:
    return text[:max_chars]

# ---------- Question keywording & validation ----------
_STOPWORDS = {
    "the","a","an","and","or","of","to","in","on","for","with","without","by","at","from","as",
    "is","are","was","were","be","been","being","do","does","did","can","could","should","would",
    "what","when","where","why","how","who","whom","which","that","this","these","those",
    "it","its","i","we","you","they","them","their","our","your","me","my","mine","ours","yours","theirs",
    "please","kindly"
}

_DOMAIN_SYNONYMS = {
    # returns/refunds
    "refund": {"refund","refunds","refunded","return","returns","exchange","exchanges","credit"},
    "return": {"return","returns","refund","exchange"},
    "days": {"day","days","business day","business days","within","deadline","window","timing"},
    "date": {"date","dates","day","days"},  # colloquial 'dates' -> treat as days
    # security / account
    "lock": {"lock","locked","unlock","lockout","failed","attempts","password","mfa","2fa","two-factor"},
    "password": {"password","passcode","passkey","credentials"},
    # incidents / SLA / retention
    "incident": {"incident","breach","compromise","sev","severity","containment","triage"},
    "sla": {"sla","response","resolution","escalate","escalation"},
    "retention": {"retention","deletion","delete","anonymise","anonymize","legal hold","backup","backups"},
}

def _extract_keywords(question: str, max_k: int = 6) -> list[str]:
    q = question.lower()
    q = re.sub(rf"[^{re.escape(string.ascii_lowercase + string.digits + ' ')}]", " ", q)
    toks = [t for t in q.split() if t and t not in _STOPWORDS and len(t) > 2]
    expanded = set()
    for t in toks:
        expanded.add(t)
        for syns in _DOMAIN_SYNONYMS.values():
            if t in syns:
                expanded |= syns
    out = []
    for t in toks:
        if t in expanded and t not in out:
            out.append(t)
        if len(out) >= max_k:
            break
    for root in ("refund","return","days","lock","incident","sla","retention","password"):
        if root in question.lower() and root not in out:
            out.append(root)
    return out[:max_k]

def _is_valid_answer(text: str) -> bool:
    if not text:
        return False
    if "|" in text and ("---" in text or re.search(r'\|\s*[-:]{3,}', text)):
        return False
    sents = [s for s in re.split(r'(?<=[.!?])\s+', text.strip()) if s]
    return 1 <= len(sents) <= 6 and len(text) <= 1500

def _is_on_topic(question: str, answer: str, min_hits: int = 1) -> bool:
    keys = _extract_keywords(question)
    if not keys:
        return True
    al = answer.lower()
    hits = sum(1 for k in keys if k in al)
    return hits >= min_hits

def _repair_prompt(bad_text: str, question: str, snippets: str) -> str:
    return (
        "Rewrite the following into ONE short paragraph (3–5 sentences). "
        "Use ONLY the facts in the snippets. Do NOT use bullet points or tables. "
        "Stay strictly on-topic with the question; ignore unrelated review or boilerplate text.\n\n"
        f"Question:\n{question}\n\nSnippets:\n{snippets}\n\n"
        f"Draft to fix:\n{bad_text}\n\nRewritten answer:"
    )

# ---------- Generic snippet-based fallback ----------
# Prefer sentences with 'N days', 'business days', 'within N days', and rule-like phrasing
def _select_relevant_sentences(snippets: str, question: str, max_sents: int = 4) -> str:
    keys = _extract_keywords(question)
    rough = re.split(r'(?<=[.!?])\s+', snippets)
    scored = []
    for s in rough:
        ss = s.strip()
        if not ss or len(ss) < 8:
            continue
        sl = ss.lower()

        # hard-penalize boilerplate
        if _is_boilerplate_line(ss):
            scored.append((-10, -len(ss), ss))
            continue

        k_hits = sum(1 for k in keys if k in sl)
        has_number = bool(re.search(r'\b\d+\b', sl))
        day_hits = len(re.findall(r'\b\d+\s*(business\s+)?days?\b', sl))
        within_hits = len(re.findall(r'\bwithin\s+\d+\s*(business\s+)?days?\b', sl, flags=re.I))
        ruleish = bool(re.search(r'\b(accepted|refund|return|replace|process|must|should|required|provide|timing|target)\b', sl))

        score = (k_hits * 2) + (day_hits * 3) + (within_hits * 4) + (1 if has_number else 0) + (2 if ruleish else 0)
        scored.append((score, -len(ss), ss))

    scored.sort(reverse=True)
    chosen = [t[2] for t in scored[:max_sents]]
    if not chosen:
        lines = [l.strip() for l in snippets.splitlines()
                 if l.strip() and not _is_boilerplate_line(l)]
        chosen = lines[:3]

    para = " ".join(chosen)
    return re.sub(r'\s+', ' ', para).strip()

# ---------- Public API ----------
def generate(question: str, mode: str = "rag", provider: str = None, model: str = None) -> dict:
    """
    Returns: {"answer": <text>, "citations": [ids...], "retrieved": [docs...] }
    """
    # Retrieval
    docs, citations, snippets = [], [], ""
    if mode in ("rag", "cot"):
        docs = retrieve(question, k=3)
        citations = [d["id"] for d in docs]
        snippets = "\n\n---\n\n".join(d["text"] for d in docs)
        snippets = _strip_md_tables(snippets)
        snippets = _sanitize_snippets(snippets)   # drop Scope/Purpose/etc.
        snippets = _trim_snippets(snippets)

    # Prompts
    if mode == "rag":
        prompt = _load_prompt("answer_rag").replace("{{question}}", question).replace("{{snippets}}", snippets)
    elif mode == "cot":
        prompt = _load_prompt("answer_cot").replace("{{question}}", question).replace("{{snippets}}", snippets)
    else:
        prompt = _load_prompt("answer_baseline").replace("{{question}}", question)

    # Call provider + validate + repair + fallback
    try:
        text = _call_provider(prompt, provider=provider, model=model).strip()

        # pass 1: form + topicality
        if (not _is_valid_answer(text)) or (not _is_on_topic(question, text, min_hits=1)):
            repair = _repair_prompt(text, question, snippets if mode in ("rag", "cot") else "")
            text = _call_provider(repair, provider=provider, model=model).strip()

        # last resort: snippet-based paragraph if still off-topic/invalid
        if (not _is_valid_answer(text)) or (not _is_on_topic(question, text, min_hits=1)):
            if mode in ("rag", "cot") and snippets:
                text = _select_relevant_sentences(snippets, question, max_sents=4)

        if not _is_valid_answer(text):
            text = "Sorry—I couldn’t produce a grounded answer from the available information."

    except Exception as e:
        if mode in ("rag", "cot") and snippets:
            text = _select_relevant_sentences(snippets, question, max_sents=4)
            if not _is_valid_answer(text):
                text = f"Sorry—generation failed ({type(e).__name__}). Please try again."
        else:
            text = f"Sorry—generation failed ({type(e).__name__}). Please try again."

    return {"answer": text, "citations": citations, "retrieved": docs}
