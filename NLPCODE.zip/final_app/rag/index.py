import os, json, glob, re
from pathlib import Path
from sentence_transformers import SentenceTransformer
import numpy as np

DATA_DIRS = ["data/company", "data/public"]
META_PATH = Path("rag/meta.json")
INDEX_NPY = Path("rag/store.npy")
EMB_MODEL = os.getenv("EMB_MODEL", "sentence-transformers/all-MiniLM-L6-v2")

def _read_md(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")

def _chunks(txt: str, max_chars=1600, overlap=200):
    # simple paragraph-ish splitter
    blocks = re.split(r"\n{2,}", txt)
    out = []
    cur = ""
    for b in blocks:
        b = b.strip()
        if not b: continue
        if len(cur) + len(b) + 1 <= max_chars:
            cur = (cur + "\n\n" + b).strip()
        else:
            if cur: out.append(cur)
            cur = b
    if cur: out.append(cur)
    # add overlaps (coarse)
    final = []
    for i, blk in enumerate(out):
        prev_tail = out[i-1][-overlap:] if i>0 else ""
        final.append((i, (prev_tail + "\n" + blk).strip()))
    return [t for _, t in final]

def build():
    META_PATH.parent.mkdir(parents=True, exist_ok=True)
    docs = []
    for d in DATA_DIRS:
        for f in sorted(glob.glob(f"{d}/**/*.md", recursive=True)):
            path = Path(f)
            text = _read_md(path)
            for i, chunk in enumerate(_chunks(text)):
                cid = f"{path.as_posix()}#{i}"
                docs.append({"id": cid, "path": path.as_posix(), "text": chunk})
    if not docs:
        raise FileNotFoundError("No .md files found in data/company or data/public")

    model = SentenceTransformer(EMB_MODEL)
    embs = model.encode([d["text"] for d in docs], show_progress_bar=True, convert_to_numpy=True, normalize_embeddings=True)

    META_PATH.write_text(json.dumps(docs, ensure_ascii=False, indent=2), encoding="utf-8")
    np.save(INDEX_NPY, embs)
    print(f"Indexed {len(docs)} chunks → {META_PATH} and {INDEX_NPY}")

if __name__ == "__main__":
    build()
