import os
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from dotenv import load_dotenv
load_dotenv()
from fastapi import Query
from sklearn.metrics import confusion_matrix, classification_report
import json
from pathlib import Path

from llm.generate import generate
from classify.traditional import predict_label
from classify.llm import classify_llm
from feedback.store import save_feedback  

app = FastAPI(title="Compliance Assistant", version="0.3.0")

class AskIn(BaseModel):
    question: str
    mode: str = "rag"  # baseline | rag | cot
    provider: Optional[str] = None
    model: Optional[str] = None

class AskOut(BaseModel):
    answer: str
    citations: List[str] = Field(default_factory=list)
    retrieved: List[dict] = Field(default_factory=list)

class ClassifyIn(BaseModel):
    text: str
    method: str = "traditional"  # traditional | llm
    provider: Optional[str] = None
    model: Optional[str] = None

class ClassifyOut(BaseModel):
    label: str
    confidence: Optional[float] = None
    reason: Optional[str] = None

# NEW: feedback schema
class FeedbackIn(BaseModel):
    question: str
    answer: str
    useful: Optional[bool] = None
    comment: Optional[str] = None
    sources: List[str] = Field(default_factory=list)

class FeedbackOut(BaseModel):
    ok: bool
    stored_as: str

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/answer", response_model=AskOut)
def answer(body: AskIn):
    try:
        out = generate(body.question, mode=body.mode)
        citations = [r["id"] for r in out.get("retrieved", [])]
        return AskOut(answer=out["answer"], citations=citations, retrieved=out["retrieved"])
    except FileNotFoundError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"generation_error: {e}")

@app.post("/classify", response_model=ClassifyOut)
def classify(body: ClassifyIn):
    try:
        low = body.text.lower()
        if any(p in low for p in [
            "can i return", "return the product", "return it",
            "refund policy", "change-of-mind", "change of mind", "exchange"
        ]):
            return ClassifyOut(label="Billing/Refunds", confidence=0.9, reason="rule: return/refund phrase")

        if body.method == "llm":
            res = classify_llm(body.text)
            label = res.get("label") or "Support Responsiveness"
            reason = res.get("reason") or ""
            return ClassifyOut(label=label, reason=reason)

        label, conf = predict_label(body.text)
        return ClassifyOut(label=label, confidence=conf)

    except Exception:
        try:
            label, conf = predict_label(body.text)
            return ClassifyOut(label=label, confidence=conf, reason="fallback: traditional")
        except Exception as e2:
            raise HTTPException(status_code=500, detail=f"classify_fatal: {e2}") 


@app.post("/feedback", response_model=FeedbackOut, status_code=201)
def feedback(body: FeedbackIn):
    try:

        payload = body.model_dump() if hasattr(body, "model_dump") else body.dict()
        save_feedback(payload)
        return FeedbackOut(ok=True, stored_as="feedback/feedback.jsonl")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"feedback_error: {e}")
def _load_eval_set() -> list[dict]:
    """Prefer classify/test.jsonl; fallback to classify/seed.jsonl."""
    for p in ["classify/test.jsonl", "classify/seed.jsonl"]:
        path = Path(p)
        if path.exists():
            rows = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
            # expect rows like {"text": "...", "label": "..."}
            return rows
    raise FileNotFoundError("No classify/test.jsonl or classify/seed.jsonl found")

@app.get("/metrics")
def metrics(method: str = Query("traditional", enum=["traditional"])):
    try:
        rows = _load_eval_set()
        y_true = [r["label"] for r in rows]
        X_texts = [r["text"] for r in rows]

        from classify.traditional import predict_bulk
        y_pred = predict_bulk(X_texts)

        labels = sorted(set(y_true) | set(y_pred))
        cm = confusion_matrix(y_true, y_pred, labels=labels)
        report = classification_report(y_true, y_pred, labels=labels, output_dict=True, zero_division=0)

        return {
            "labels": labels,
            "confusion_matrix": cm.tolist(),
            "report": report  # dict with precision/recall/f1/support per class + macro/weighted avg
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"metrics_error: {e}")