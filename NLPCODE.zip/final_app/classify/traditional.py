# classify/traditional.py
import json, pathlib, joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from typing import List, Tuple
MODEL = pathlib.Path("classify/model.joblib")
VEC   = pathlib.Path("classify/vectorizer.joblib")
SEED  = pathlib.Path("classify/seed.jsonl")

def _ensure_trained():
    if MODEL.exists() and VEC.exists():
        return
    if not SEED.exists():
        raise FileNotFoundError("Missing classify/seed.jsonl and no trained model found.")
    rows=[json.loads(l) for l in SEED.read_text(encoding="utf-8").splitlines() if l.strip()]
    if not rows:
        raise ValueError("seed.jsonl is empty.")
    X=[r["text"] for r in rows]; y=[r["label"] for r in rows]
    vec=TfidfVectorizer(ngram_range=(1,2), min_df=1, max_df=0.9)
    Xv=vec.fit_transform(X)
    clf=LogisticRegression(max_iter=2000, class_weight="balanced").fit(Xv,y)
    joblib.dump(clf, MODEL); joblib.dump(vec, VEC)

def predict_label(text: str):
    _ensure_trained()
    clf = joblib.load(MODEL); vec = joblib.load(VEC)
    proba = clf.predict_proba(vec.transform([text]))[0]
    i = proba.argmax()
    return clf.classes_[i], float(proba[i])
_VEC = None
_CLF = None
_LABELS = None

def _load_artifacts():
    global _VEC, _CLF
    if _VEC is None:
        _VEC = joblib.load("classify/vectorizer.joblib")
    if _CLF is None:
        _CLF = joblib.load("classify/model.joblib")
    return _VEC, _CLF

def predict_bulk(texts: List[str]) -> List[str]:
    vec, clf = _load_artifacts()
    X = vec.transform(texts)
    return clf.predict(X).tolist()