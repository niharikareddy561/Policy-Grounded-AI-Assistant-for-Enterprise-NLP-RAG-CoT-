# classify/llm.py
import os, json, re, requests
from pathlib import Path

_HF_PIPE = None

def _read_prompt():
    return Path("prompts/classify_llm.txt").read_text(encoding="utf-8")

def _hf_pipe():
    global _HF_PIPE
    if _HF_PIPE is None:
        from transformers import pipeline
        _HF_PIPE = pipeline("text2text-generation", model=os.getenv("HF_LLM_MODEL","google/flan-t5-small"))
    return _HF_PIPE

def _extract_json(txt: str) -> dict:
    # Try strict first
    try:
        return json.loads(txt)
    except Exception:
        pass
    # Try to pull the largest {...} block
    m = re.search(r"\{.*\}", txt, flags=re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass
    # Heuristic fallback using keywords
    low = txt.lower()
    if any(k in low for k in ["return", "refund", "exchange", "change of mind"]):
        return {"label":"Billing/Refunds","reason":"heuristic: refund/return keywords"}
    if any(k in low for k in ["deliver", "courier", "parcel", "tracking", "lost", "damaged in transit"]):
        return {"label":"Delivery/Logistics","reason":"heuristic: delivery keywords"}
    if any(k in low for k in ["password", "suspicious", "login", "privacy", "fraud", "unauthorized"]):
        return {"label":"Security/Fraud","reason":"heuristic: security keywords"}
    if any(k in low for k in ["great", "amazing", "love", "thanks", "five stars"]):
        return {"label":"Praise","reason":"heuristic: positive keywords"}
    return {"label":"Support Responsiveness","reason":"heuristic: default"}

def classify_llm(text: str, provider: str = None, model: str = None) -> dict:
    prompt = _read_prompt().replace("{{text}}", text.strip())
    prov = provider or os.getenv("LLM_PROVIDER", "hf")
    try:
        if prov == "openai":
            om = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
            # ... OpenAI call with response_format json_object and om ...
        elif prov == "local":
            ol = model or os.getenv("OLLAMA_MODEL", "qwen2.5:0.5b")
            # ... Ollama call with ol ...
        else:
            hf = model or os.getenv("HF_LLM_MODEL", "google/flan-t5-small")
            from transformers import pipeline
            pipe = pipeline("text2text-generation", model=hf)
            out = pipe(prompt, max_new_tokens=200, do_sample=False, temperature=0.0)[0]["generated_text"]
            # ... robust JSON extraction as you already implemented ...
    except Exception as e:
        return {"label":"Support Responsiveness","reason":f"fallback: {type(e).__name__}"}
