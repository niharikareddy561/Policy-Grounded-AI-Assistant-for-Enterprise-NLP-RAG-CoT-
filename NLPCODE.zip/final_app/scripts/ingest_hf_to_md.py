import argparse, os, re
from datasets import load_dataset
from pathlib import Path
from datetime import date

def slugify(s,n=60):
    s=s.lower().strip(); s=re.sub(r"[^a-z0-9]+","-",s).strip("-"); return s[:n] or "item"

def star_to_label(stars:int):
    if stars in (1,2): return "Complaint"
    if stars in (4,5): return "Praise"
    return "Support Responsiveness"

ap = argparse.ArgumentParser()
ap.add_argument("--name", default="mteb/amazon_reviews_multi")
ap.add_argument("--lang", default="en")
ap.add_argument("--split", default="train[:3000]")
ap.add_argument("--outfile", default="data/public/amazon_en_train_sample.md")
args = ap.parse_args()

ds = load_dataset(args.name, args.lang, split=args.split)
Path("data/public").mkdir(parents=True, exist_ok=True)
blocks=[]
for i, ex in enumerate(ds):
    title=(ex.get("review_title","") or "").strip().replace("\n", " ")
    body =(ex.get("review_body","")  or "").strip()
    if not body: continue
    stars=int(ex.get("stars",3))
    rid=f"{slugify(title or body[:40])}-{i}"
    label=star_to_label(stars)
    blocks.append(f"""## {rid}

**label:** {label}
**stars:** {stars}

{('**title:** '+title+'\\n\\n') if title else ''}{body}
""")

content=f"<!-- Source: {args.name} ({args.lang}/{args.split}), exported {date.today().isoformat()} -->\n\n"
content += ("\n\n---\n\n".join(blocks) if blocks else "# empty\n")
Path(args.outfile).write_text(content, encoding="utf-8")
print(f"Wrote {args.outfile} with {len(blocks)} items.")
