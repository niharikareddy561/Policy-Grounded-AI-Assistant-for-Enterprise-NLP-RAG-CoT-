# scripts/train_classifier.py
import json, pathlib, joblib, argparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

def train(seed_path: str, model_out: str, vec_out: str):
    p = pathlib.Path(seed_path)
    if not p.exists():
        raise FileNotFoundError(f"{seed_path} not found")
    rows = [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
    if not rows:
        raise ValueError("seed file is empty")

    X = [r["text"] for r in rows]
    y = [r["label"] for r in rows]

    vec = TfidfVectorizer(ngram_range=(1,2), min_df=1, max_df=0.9)
    Xv = vec.fit_transform(X)
    clf = LogisticRegression(max_iter=2000, class_weight="balanced").fit(Xv, y)

    joblib.dump(clf, model_out)
    joblib.dump(vec, vec_out)
    print("Saved:", model_out, "and", vec_out)
    print("Classes:", sorted(set(y)), "N:", len(y))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", default="classify/seed.jsonl")
    ap.add_argument("--model-out", default="classify/model.joblib")
    ap.add_argument("--vec-out", default="classify/vectorizer.joblib")
    args = ap.parse_args()
    train(args.seed, args.model_out, args.vec_out)
